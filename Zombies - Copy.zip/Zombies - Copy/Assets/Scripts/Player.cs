﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float baseSpeed;
    public float runningAmplifier;

    public bool lockCursor;

    private CharacterController charController;
    private Animator animator;
    private PlayerMovementInfo playerMovement;

    private float airTime;
    private float gravity = -9.81f;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        charController = GetComponent<CharacterController>();
        playerMovement = new PlayerMovementInfo();

        playerMovement.baseSpeed = baseSpeed;
        playerMovement.runningAmplifier = runningAmplifier;

        if(lockCursor)
        {
            Cursor.lockState = CursorLockMode.Locked;
        }

        airTime = 0;

    }

    // Update is called once per frame
    void Update()
    {
        ProcessInput();

        PerformBlendTreeAnimation();

        CalculateDirectionAndDistance();

        PerdformPhysicalMovement();

        RotatePlayerWithCamera();
    }

    public void ProcessInput()
    {
        playerMovement.leftAndRight = Input.GetAxis("Horizontal");
        playerMovement.forwardAndBackward = Input.GetAxis("Vertical");


        playerMovement.movingForwards = playerMovement.forwardAndBackward > 0f;
        playerMovement.movingBackwards = playerMovement.forwardAndBackward < 0f;

        bool running = (!playerMovement.movingBackwards && Input.GetKey(KeyCode.LeftShift));

        if(running)
        {
            playerMovement.speed = playerMovement.baseSpeed * playerMovement.runningAmplifier;
        }
        else
        {
            playerMovement.speed = playerMovement.baseSpeed;
            playerMovement.forwardAndBackward = playerMovement.forwardAndBackward / 2f;
            playerMovement.leftAndRight = playerMovement.leftAndRight / 2f;
        }
    }

    public void PerformBlendTreeAnimation()
    {
        float leftandRight = playerMovement.leftAndRight;

        if(playerMovement.movingBackwards)
        {
            leftandRight = 0f;
        }

        animator.SetFloat("leftAndRight", leftandRight);
        animator.SetFloat("forwardAndBackward", playerMovement.forwardAndBackward);
    }

    public void CalculateDirectionAndDistance()
    {
        Vector3 moveDirectionForward = transform.forward * playerMovement.forwardAndBackward;
        Vector3 moveDirectionSide = transform.right * playerMovement.leftAndRight;

        playerMovement.direction = moveDirectionForward + moveDirectionSide;
        playerMovement.normalizedDirection = playerMovement.direction.normalized;

        GroundPlayer();

        playerMovement.distance = playerMovement.normalizedDirection * playerMovement.speed * Time.deltaTime;

    }

    public void PerdformPhysicalMovement()
    {
        charController.Move(playerMovement.distance);
    }

    public void GroundPlayer()
    {
        if(charController.isGrounded)
        {
            airTime = 0;
        }
        else
        {
            airTime += Time.deltaTime;
            Vector3 direction = playerMovement.normalizedDirection;

            direction.y += 0.5f * gravity * airTime;

            playerMovement.normalizedDirection = direction;
            //playerMovement.distance = playerMovement.normalizedDirection * airTime;
        }
    }

    public void RotatePlayerWithCamera()
    {
        Vector3 rotation;

        if(Input.GetKey(KeyCode.T))
        {
            return;
        }
        else
        {
            rotation = Camera.main.transform.eulerAngles;
            rotation.x = 0;
            rotation.z = 0;

            transform.eulerAngles = rotation;
        }
    }
}

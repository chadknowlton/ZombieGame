﻿using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    public static PlayerManager Instance; 
    void Awake()
    {
        Instance = this;
    }

    public GameObject player;
}
